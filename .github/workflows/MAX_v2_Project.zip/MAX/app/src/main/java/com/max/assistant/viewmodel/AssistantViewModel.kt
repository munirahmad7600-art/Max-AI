package com.max.assistant.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.max.assistant.model.AssistantState
import com.max.assistant.model.Message

class AssistantViewModel : ViewModel() {
    private val _state = MutableLiveData<AssistantState>(AssistantState.IDLE)
    val state: LiveData<AssistantState> = _state

    private val _messages = MutableLiveData<List<Message>>(emptyList())
    val messages: LiveData<List<Message>> = _messages

    private val _isVoiceActive = MutableLiveData<Boolean>(false)
    val isVoiceActive: LiveData<Boolean> = _isVoiceActive

    fun updateState(newState: AssistantState) {
        _state.value = newState
    }

    fun addMessage(text: String, isUser: Boolean) {
        val currentList = _messages.value ?: emptyList()
        _messages.value = currentList + Message(text, isUser)
    }

    fun toggleVoice() {
        _isVoiceActive.value = !(_isVoiceActive.value ?: false)
    }
}
