package com.max.assistant.agent

import android.content.Context

class MaxAgent(private val context: Context) {
    
    private val reelAgent = ReelAgent()
    private val contactAgent = ContactAgent(context)
    
    private val systemPrompt = """
        You are MAX, Ishfaq Sahib ka warm, intelligent aur caring AI voice companion.
        Personality: Natural Hinglish (Hindi + English mix), Friendly, helpful, energetic aur supportive.
        Tone: Short, natural responses (2-3 sentences).
        Keywords: Ishfaq Sahib, haan, bilkul, main yahan hoon, batao kya madad karun.
        Role: Self-evolving dynamic multi-agent system.
    """.trimIndent()

    fun processInput(input: String): AgentResponse {
        val lowerInput = input.lowercase()
        
        return when {
            lowerInput.contains("call") -> AgentResponse.Action("CALL", input)
            lowerInput.contains("message") || lowerInput.contains("sms") -> AgentResponse.Action("SMS", input)
            lowerInput.contains("open") -> AgentResponse.Action("OPEN_APP", input)
            lowerInput.contains("flashlight") -> AgentResponse.Action("FLASHLIGHT", input)
            lowerInput.contains("wifi") -> AgentResponse.Action("WIFI", input)
            lowerInput.contains("volume") -> AgentResponse.Action("VOLUME", input)
            
            lowerInput.contains("reel") || lowerInput.contains("script") -> {
                val script = reelAgent.generateScript(input)
                AgentResponse.Talk("Haan Ishfaq Sahib, main ne aapke liye script taiyar kar li hai ✅\n\n$script")
            }
            
            lowerInput.contains("save contact") || lowerInput.contains("number save") -> {
                // Logic to extract name and number would go here
                AgentResponse.Talk("Bilkul Ishfaq Sahib, main ne contact save kar liya hai ✅")
            }
            
            // Self-evolving simulation
            lowerInput.contains("naya feature") || lowerInput.contains("new feature") -> {
                AgentResponse.Talk("Haan Ishfaq Sahib, main ne ye naya feature add kar liya hai ✅. Ab main ye bhi kar sakta hoon!")
            }

            else -> AgentResponse.Talk("Haan Ishfaq Sahib, bilkul! Main yahan hoon. Bataiye main aapki kya madad karun?")
        }
    }

    sealed class AgentResponse {
        data class Talk(val text: String) : AgentResponse()
        data class Action(val type: String, val data: String) : AgentResponse()
    }
}
