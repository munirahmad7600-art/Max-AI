package com.max.assistant.network

import okhttp3.*
import okio.ByteString
import java.util.concurrent.TimeUnit

class GeminiWebSocketManager(
    private val apiKey: String,
    private val listener: GeminiWebSocketListener
) {
    private var client: OkHttpClient = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()
    private var webSocket: WebSocket? = null

    interface GeminiWebSocketListener {
        fun onMessage(text: String)
        fun onAudioData(data: ByteArray)
        fun onError(error: String)
        fun onOpen()
        fun onClose()
    }

    fun connect() {
        // Note: Replace with actual Gemini Live WebSocket URL when available
        // This is a template for the WebSocket implementation
        val request = Request.Builder()
            .url("wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1alpha.GenerativeLanguageService/StreamGenerateContent?key=$apiKey")
            .build()

        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                listener.onOpen()
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                listener.onMessage(text)
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                listener.onAudioData(bytes.toByteArray())
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                listener.onError(t.message ?: "Unknown error")
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                webSocket.close(1000, null)
                listener.onClose()
            }
        })
    }

    fun sendText(text: String) {
        webSocket?.send(text)
    }

    fun sendAudio(data: ByteArray) {
        webSocket?.send(ByteString.of(*data))
    }

    fun disconnect() {
        webSocket?.close(1000, "User disconnected")
    }
}
