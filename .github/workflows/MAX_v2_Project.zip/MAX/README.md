# MAX v2.0 — Self-Evolving Android AI Voice Assistant

Assalam-o-Alaikum Ishfaq Sahib! Here is your custom-built AI assistant, **MAX**, optimized for your **Oppo F15**.

## 🚀 Key Features
- **Floating Orb UI:** A small, glowing blue orb that stays on your screen.
- **Gemini Live Voice:** Real-time Hinglish conversation (Hindi + English).
- **Device Controls:** "MAX, call Ishfaq", "MAX, turn on flashlight", "MAX, open WhatsApp".
- **Self-Evolving:** If you ask for something new, MAX simulates adding that feature instantly.
- **Specialized Agents:**
    - **Reel Script Gen:** "MAX, ek cricket reel script likho."
    - **Urdu Contacts:** Saves contacts with Urdu support.
- **Oppo F15 Optimized:** Battery efficient and lightweight.

## 🛠 Setup Instructions
1. **Build the APK:** Open this project in Android Studio and click 'Build APK'.
2. **Permissions:** When you open the app, click **SETUP MAX**. It will ask for:
    - Microphone (for voice)
    - Overlay (for the floating orb)
    - Accessibility (for screen control)
    - Battery Optimization (to keep MAX alive)
3. **Usage:**
    - **Single Tap Orb:** Speak to MAX.
    - **Double Tap Orb:** Toggle voice mode.
    - **Drag Orb:** Move it anywhere on your screen.

## 📦 Package Structure
- `com.max.assistant`
- **Kotlin + MVVM**
- **WebSocket** for real-time AI.

Enjoy your new assistant, Ishfaq Sahib! ✅
